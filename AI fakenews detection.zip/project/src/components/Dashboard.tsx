import React, { useState, useEffect } from 'react';
import { Thermometer, Wind, Droplets, Eye, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

const Dashboard: React.FC = () => {
  const [realTimeData, setRealTimeData] = useState({
    temperature: 34.2,
    humidity: 23,
    windSpeed: 15.7,
    visibility: 8.2,
    riskLevel: 'HIGH',
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        temperature: prev.temperature + (Math.random() - 0.5) * 2,
        humidity: Math.max(0, Math.min(100, prev.humidity + (Math.random() - 0.5) * 5)),
        windSpeed: Math.max(0, prev.windSpeed + (Math.random() - 0.5) * 3),
        visibility: Math.max(0, Math.min(20, prev.visibility + (Math.random() - 0.5) * 2)),
        riskLevel: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'][Math.floor(Math.random() * 4)],
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const riskColors = {
    LOW: 'text-green-400 border-green-400 bg-green-400/10',
    MEDIUM: 'text-yellow-400 border-yellow-400 bg-yellow-400/10',
    HIGH: 'text-fire-400 border-fire-400 bg-fire-400/10',
    CRITICAL: 'text-danger-400 border-danger-400 bg-danger-400/10',
  };

  const metrics = [
    {
      label: 'Temperature',
      value: `${realTimeData.temperature.toFixed(1)}°C`,
      icon: Thermometer,
      trend: realTimeData.temperature > 30 ? 'up' : 'down',
      color: 'text-fire-400',
    },
    {
      label: 'Humidity',
      value: `${realTimeData.humidity.toFixed(0)}%`,
      icon: Droplets,
      trend: realTimeData.humidity < 30 ? 'down' : 'up',
      color: 'text-cyber-400',
    },
    {
      label: 'Wind Speed',
      value: `${realTimeData.windSpeed.toFixed(1)} km/h`,
      icon: Wind,
      trend: realTimeData.windSpeed > 15 ? 'up' : 'down',
      color: 'text-gray-400',
    },
    {
      label: 'Visibility',
      value: `${realTimeData.visibility.toFixed(1)} km`,
      icon: Eye,
      trend: realTimeData.visibility > 5 ? 'up' : 'down',
      color: 'text-purple-400',
    },
  ];

  return (
    <section id="dashboard" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Live <span className="gradient-cyber bg-clip-text text-transparent">Dashboard</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Real-time environmental monitoring and fire risk assessment powered by our AI prediction engine
          </p>
        </motion.div>

        {/* Risk Level Alert */}
        <motion.div
          className={`mb-12 p-6 rounded-xl border-2 glass ${riskColors[realTimeData.riskLevel as keyof typeof riskColors]} scanning-line`}
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-center space-x-4">
            <AlertTriangle className="w-8 h-8" />
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-2">Current Risk Level: {realTimeData.riskLevel}</h3>
              <p className="text-sm opacity-80">
                Based on current environmental conditions and AI predictions
              </p>
            </div>
          </div>
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {metrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              className="glass rounded-xl p-6 card-hover"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center justify-between mb-4">
                <metric.icon className={`w-8 h-8 ${metric.color}`} />
                {metric.trend === 'up' ? (
                  <TrendingUp className="w-5 h-5 text-green-400" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-400" />
                )}
              </div>
              <div className="text-3xl font-bold text-white mb-2 font-mono">
                {metric.value}
              </div>
              <div className="text-sm text-gray-400">{metric.label}</div>
            </motion.div>
          ))}
        </div>

        {/* AI Predictions Panel */}
        <motion.div
          className="glass rounded-2xl p-8"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <span className="w-3 h-3 bg-green-400 rounded-full mr-3 pulse-ring"></span>
            AI Prediction Engine
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Fire Risk Chart */}
            <div className="lg:col-span-2">
              <h4 className="text-lg font-semibold text-gray-300 mb-4">24-Hour Fire Risk Forecast</h4>
              <div className="h-32 bg-gray-800/50 rounded-lg p-4 relative overflow-hidden">
                <div className="absolute inset-0 gradient-fire opacity-20 rounded-lg"></div>
                <div className="relative z-10">
                  <div className="text-4xl font-bold text-fire-400 mb-2">87%</div>
                  <div className="text-sm text-gray-400">Peak risk at 14:00 - 16:00</div>
                </div>
                <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                  Updated 2 min ago
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="space-y-4">
              <div className="bg-gray-800/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Active Alerts</div>
                <div className="text-2xl font-bold text-fire-400">23</div>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Sensors Online</div>
                <div className="text-2xl font-bold text-green-400">847/852</div>
              </div>
              <div className="bg-gray-800/50 rounded-lg p-4">
                <div className="text-sm text-gray-400 mb-1">Coverage Area</div>
                <div className="text-2xl font-bold text-cyber-400">2,847 km²</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Dashboard;