import React, { useEffect, useState } from 'react';
import { Shield, Zap, Globe, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import ParticleBackground from './ParticleBackground';

const Hero: React.FC = () => {
  const [currentStat, setCurrentStat] = useState(0);

  const stats = [
    { label: 'Active Monitoring Zones', value: '2,847', icon: Globe },
    { label: 'Prevented Fire Incidents', value: '1,293', icon: Shield },
    { label: 'Real-time Sensors', value: '15,672', icon: Zap },
    { label: 'Prediction Accuracy', value: '94.7%', icon: TrendingUp },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [stats.length]);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <ParticleBackground />
      
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-fire-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyber-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Main Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-8"
        >
          <motion.h1
            className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.2 }}
          >
            <span className="gradient-fire bg-clip-text text-transparent text-glow">
              ForestGuard
            </span>
            <br />
            <span className="text-white">AI System</span>
          </motion.h1>
          
          <motion.p
            className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            Advanced AI-powered forest fire prediction and monitoring system
            using real-time environmental data, satellite imagery, and machine learning
            to protect our forests and communities.
          </motion.p>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
        >
          <motion.button
            className="px-8 py-4 gradient-fire text-white font-semibold rounded-lg shadow-2xl hover:shadow-fire-500/50 transition-all duration-300 transform hover:scale-105"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Launch Dashboard
          </motion.button>
          
          <motion.button
            className="px-8 py-4 glass border border-white/20 text-white font-semibold rounded-lg hover:border-white/40 transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            View Live Demo
          </motion.button>
        </motion.div>

        {/* Dynamic Stats */}
        <motion.div
          className="glass rounded-2xl p-8 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1 }}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                className={`text-center transition-all duration-500 ${
                  index === currentStat ? 'scale-110 opacity-100' : 'opacity-60'
                }`}
                whileHover={{ scale: 1.1 }}
              >
                <div className="relative mb-4">
                  <stat.icon className={`w-8 h-8 mx-auto ${
                    index === currentStat ? 'text-fire-400' : 'text-gray-400'
                  }`} />
                  {index === currentStat && (
                    <motion.div
                      className="absolute inset-0 bg-fire-500 blur-lg opacity-30"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      key={currentStat}
                    />
                  )}
                </div>
                <div className={`text-2xl md:text-3xl font-bold mb-2 font-mono ${
                  index === currentStat ? 'text-fire-400' : 'text-white'
                }`}>
                  {stat.value}
                </div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
        >
          <motion.div
            className="w-6 h-6 border-2 border-white/50 rounded-full flex items-center justify-center"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-1 h-1 bg-white rounded-full" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;