import React, { useState } from 'react';
import { CheckCircle, Clock, AlertCircle, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Timeline: React.FC = () => {
  const [activePhase, setActivePhase] = useState(0);

  const phases = [
    {
      title: 'Data Collection',
      status: 'completed',
      time: '00:00 - 00:15',
      description: 'Gathering real-time environmental data from satellites, weather stations, and IoT sensors across monitored regions.',
      details: [
        'NASA MODIS satellite imagery processed',
        'Weather API data synchronized',
        'IoT sensor readings collected',
        'Historical fire data updated'
      ]
    },
    {
      title: 'AI Processing',
      status: 'completed',
      time: '00:15 - 00:45',
      description: 'Advanced machine learning models analyze environmental patterns and assess fire risk probability.',
      details: [
        'CNN models process satellite imagery',
        'LSTM networks analyze weather patterns',
        'Feature extraction completed',
        'Risk calculations finalized'
      ]
    },
    {
      title: 'Risk Assessment',
      status: 'active',
      time: '00:45 - 01:00',
      description: 'Comprehensive risk evaluation combining multiple data sources to generate accurate fire probability scores.',
      details: [
        'Multi-factor risk analysis in progress',
        'Geographic risk mapping active',
        'Threat level classification ongoing',
        'Alert thresholds being evaluated'
      ]
    },
    {
      title: 'Alert Generation',
      status: 'pending',
      time: '01:00 - 01:15',
      description: 'Automated alert system prepares notifications for high-risk areas and relevant authorities.',
      details: [
        'Alert prioritization pending',
        'Notification routing queued',
        'Emergency contact preparation',
        'Response coordination standby'
      ]
    }
  ];

  const statusIcons = {
    completed: CheckCircle,
    active: Play,
    pending: Clock,
  };

  const statusColors = {
    completed: 'text-green-400 bg-green-400/20 border-green-400/30',
    active: 'text-fire-400 bg-fire-400/20 border-fire-400/30',
    pending: 'text-gray-400 bg-gray-400/20 border-gray-400/30',
  };

  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            AI Processing <span className="gradient-cyber bg-clip-text text-transparent">Pipeline</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Real-time visualization of our AI system's continuous processing cycle,
            from data ingestion to actionable fire risk alerts.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Timeline */}
          <div className="lg:col-span-2">
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-green-400 via-fire-400 to-gray-400" />

              {phases.map((phase, index) => {
                const Icon = statusIcons[phase.status as keyof typeof statusIcons];
                
                return (
                  <motion.div
                    key={phase.title}
                    className={`relative mb-12 cursor-pointer ${
                      activePhase === index ? 'scale-105' : ''
                    }`}
                    onClick={() => setActivePhase(index)}
                    initial={{ opacity: 0, x: -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, delay: index * 0.2 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.02 }}
                  >
                    {/* Timeline Node */}
                    <div className={`absolute left-0 w-16 h-16 rounded-2xl border-2 flex items-center justify-center ${
                      statusColors[phase.status as keyof typeof statusColors]
                    } ${phase.status === 'active' ? 'animate-pulse' : ''}`}>
                      <Icon className="w-8 h-8" />
                    </div>

                    {/* Content */}
                    <div className="ml-24 glass rounded-xl p-6 card-hover">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-xl font-bold text-white">{phase.title}</h3>
                        <span className="text-sm text-gray-400 font-mono">{phase.time}</span>
                      </div>
                      <p className="text-gray-400 mb-4">{phase.description}</p>
                      
                      {/* Progress Bar */}
                      <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                        <motion.div
                          className={`h-2 rounded-full ${
                            phase.status === 'completed' 
                              ? 'bg-green-400' 
                              : phase.status === 'active' 
                                ? 'bg-fire-400' 
                                : 'bg-gray-500'
                          }`}
                          initial={{ width: 0 }}
                          animate={{ 
                            width: phase.status === 'completed' 
                              ? '100%' 
                              : phase.status === 'active' 
                                ? '65%' 
                                : '0%' 
                          }}
                          transition={{ duration: 2, delay: index * 0.5 }}
                        />
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Phase Details */}
          <div className="glass rounded-2xl p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={activePhase}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h3 className="text-2xl font-bold text-white mb-6">
                  {phases[activePhase].title} Details
                </h3>
                
                <div className="space-y-4">
                  {phases[activePhase].details.map((detail, index) => (
                    <motion.div
                      key={detail}
                      className="flex items-center space-x-3"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <div className={`w-2 h-2 rounded-full ${
                        phases[activePhase].status === 'completed' 
                          ? 'bg-green-400' 
                          : phases[activePhase].status === 'active' 
                            ? 'bg-fire-400' 
                            : 'bg-gray-400'
                      }`} />
                      <span className="text-gray-300">{detail}</span>
                    </motion.div>
                  ))}
                </div>

                {/* Live Status */}
                <div className="mt-8 p-4 bg-gray-800/50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${
                      phases[activePhase].status === 'active' ? 'bg-fire-400 animate-pulse' : 'bg-gray-400'
                    }`} />
                    <span className="text-sm text-gray-400">
                      Status: <span className="text-white capitalize">{phases[activePhase].status}</span>
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    Last updated: {new Date().toLocaleTimeString()}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Timeline;