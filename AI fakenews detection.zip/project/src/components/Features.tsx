import React from 'react';
import { Satellite, Brain, Shield, Zap, Eye, Globe } from 'lucide-react';
import { motion } from 'framer-motion';

const Features: React.FC = () => {
  const features = [
    {
      icon: Satellite,
      title: 'Satellite Integration',
      description: 'Real-time data from NASA MODIS, Sentinel-2, and VIIRS wildfire datasets for comprehensive monitoring.',
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
    },
    {
      icon: Brain,
      title: 'AI Prediction Engine',
      description: 'Advanced CNN and LSTM models for accurate fire risk prediction and spread simulation.',
      color: 'text-fire-400',
      bgColor: 'bg-fire-400/10',
    },
    {
      icon: Shield,
      title: 'Early Warning System',
      description: 'Proactive alerts and notifications to prevent fire incidents before they occur.',
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
    },
    {
      icon: Zap,
      title: 'Real-time Processing',
      description: 'Lightning-fast data processing with Apache Kafka and MQTT for instant updates.',
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
    },
    {
      icon: Eye,
      title: 'Environmental Monitoring',
      description: 'IoT sensors tracking temperature, humidity, wind patterns, and vegetation conditions.',
      color: 'text-cyber-400',
      bgColor: 'bg-cyber-400/10',
    },
    {
      icon: Globe,
      title: 'Geospatial Analysis',
      description: 'Interactive maps with risk zones, fire spread visualization, and coverage analytics.',
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-400/10',
    },
  ];

  return (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Advanced <span className="gradient-fire bg-clip-text text-transparent">AI Features</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Cutting-edge technology stack designed to predict, monitor, and prevent forest fires
            with unprecedented accuracy and speed.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              className="relative group"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="glass rounded-2xl p-8 h-full card-hover relative overflow-hidden">
                {/* Background glow effect */}
                <div className={`absolute inset-0 ${feature.bgColor} opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl`} />
                
                <div className="relative z-10">
                  <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl ${feature.bgColor} mb-6`}>
                    <feature.icon className={`w-8 h-8 ${feature.color}`} />
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{feature.description}</p>
                  
                  {/* Scanning line effect */}
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Technology Stack */}
        <motion.div
          className="mt-20"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-white text-center mb-12">
            Powered by Industry-Leading Technologies
          </h3>
          
          <div className="glass rounded-2xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {[
                'TensorFlow', 'PyTorch', 'React', 'Node.js', 'PostgreSQL', 'Docker'
              ].map((tech, index) => (
                <motion.div
                  key={tech}
                  className="text-center group cursor-pointer"
                  whileHover={{ scale: 1.1 }}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <div className="w-16 h-16 mx-auto mb-3 glass rounded-xl flex items-center justify-center group-hover:border-fire-400/50 transition-all duration-300">
                    <span className="text-2xl font-bold text-fire-400">{tech.charAt(0)}</span>
                  </div>
                  <div className="text-sm text-gray-400 group-hover:text-white transition-colors duration-300">
                    {tech}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;