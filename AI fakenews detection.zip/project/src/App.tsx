import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Home from './pages/Home';
import LiveDemo from './pages/LiveDemo';
import Predictions from './pages/Predictions';
import RiskMap from './pages/RiskMap';
import LiveMonitoring from './pages/LiveMonitoring';
import Settings from './pages/Settings';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white overflow-x-hidden">
        <Navigation />
        <main className="pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/live-demo" element={<LiveDemo />} />
            <Route path="/predictions" element={<Predictions />} />
            <Route path="/risk-map" element={<RiskMap />} />
            <Route path="/live-monitoring" element={<LiveMonitoring />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;