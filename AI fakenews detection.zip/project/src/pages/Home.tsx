import React from 'react';
import Hero from '../components/Hero';
import Dashboard from '../components/Dashboard';
import Features from '../components/Features';
import Timeline from '../components/Timeline';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <Dashboard />
      <Features />
      <Timeline />
    </>
  );
};

export default Home;