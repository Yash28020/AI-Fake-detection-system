import React, { useState, useEffect } from 'react';
import { TrendingUp, AlertTriangle, Calendar, MapPin, Thermometer, Wind } from 'lucide-react';
import { motion } from 'framer-motion';

const Predictions: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('24h');
  const [predictions, setPredictions] = useState([
    {
      id: 1,
      location: 'Yellowstone National Park',
      riskLevel: 'HIGH',
      probability: 87,
      timeframe: '6-12 hours',
      factors: ['High temperature', 'Low humidity', 'Strong winds'],
      coordinates: { lat: 44.4280, lng: -110.5885 }
    },
    {
      id: 2,
      location: 'Angeles National Forest',
      riskLevel: 'CRITICAL',
      probability: 94,
      timeframe: '2-4 hours',
      factors: ['Extreme heat', 'Drought conditions', 'Santa Ana winds'],
      coordinates: { lat: 34.2549, lng: -117.8677 }
    },
    {
      id: 3,
      location: 'Olympic National Forest',
      riskLevel: 'MEDIUM',
      probability: 45,
      timeframe: '12-24 hours',
      factors: ['Moderate temperature', 'Recent rainfall'],
      coordinates: { lat: 47.8021, lng: -123.6044 }
    },
    {
      id: 4,
      location: 'Great Smoky Mountains',
      riskLevel: 'LOW',
      probability: 23,
      timeframe: '24-48 hours',
      factors: ['High humidity', 'Stable weather'],
      coordinates: { lat: 35.6118, lng: -83.4895 }
    }
  ]);

  const riskColors = {
    LOW: 'text-green-400 border-green-400 bg-green-400/10',
    MEDIUM: 'text-yellow-400 border-yellow-400 bg-yellow-400/10',
    HIGH: 'text-fire-400 border-fire-400 bg-fire-400/10',
    CRITICAL: 'text-red-500 border-red-500 bg-red-500/10',
  };

  const timeframes = ['6h', '12h', '24h', '48h', '7d'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Hero Section with Mountain Background */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Mountain forest landscape"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/80" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-fire bg-clip-text text-transparent">AI Predictions</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Advanced machine learning models provide accurate fire risk predictions
              across monitored forest regions with real-time environmental analysis.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Timeframe Selector */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="glass rounded-2xl p-6 mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between">
              <h2 className="text-2xl font-bold text-white mb-4 md:mb-0 flex items-center">
                <Calendar className="w-6 h-6 mr-3 text-cyber-400" />
                Prediction Timeframe
              </h2>
              
              <div className="flex items-center space-x-2">
                {timeframes.map((timeframe) => (
                  <motion.button
                    key={timeframe}
                    onClick={() => setSelectedTimeframe(timeframe)}
                    className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                      selectedTimeframe === timeframe
                        ? 'gradient-fire text-white'
                        : 'glass border border-white/20 text-gray-300 hover:border-white/40'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {timeframe}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Predictions Grid */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {predictions.map((prediction, index) => (
              <motion.div
                key={prediction.id}
                className="glass rounded-2xl p-8 card-hover"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2 flex items-center">
                      <MapPin className="w-6 h-6 mr-3 text-cyber-400" />
                      {prediction.location}
                    </h3>
                    <p className="text-gray-400">Risk assessment for next {prediction.timeframe}</p>
                  </div>
                  
                  <div className={`px-4 py-2 rounded-lg border-2 font-bold ${
                    riskColors[prediction.riskLevel as keyof typeof riskColors]
                  }`}>
                    {prediction.riskLevel}
                  </div>
                </div>

                {/* Risk Probability */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400">Fire Risk Probability</span>
                    <span className="text-2xl font-bold text-fire-400 font-mono">
                      {prediction.probability}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <motion.div
                      className={`h-3 rounded-full ${
                        prediction.probability >= 80 
                          ? 'bg-red-500' 
                          : prediction.probability >= 60 
                            ? 'bg-fire-400' 
                            : prediction.probability >= 40 
                              ? 'bg-yellow-400' 
                              : 'bg-green-400'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${prediction.probability}%` }}
                      transition={{ duration: 1.5, delay: index * 0.2 }}
                    />
                  </div>
                </div>

                {/* Contributing Factors */}
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-white mb-3 flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-fire-400" />
                    Contributing Factors
                  </h4>
                  <div className="space-y-2">
                    {prediction.factors.map((factor, factorIndex) => (
                      <motion.div
                        key={factorIndex}
                        className="flex items-center space-x-3 p-3 bg-gray-800/50 rounded-lg"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: (index * 0.1) + (factorIndex * 0.1) }}
                      >
                        <AlertTriangle className="w-4 h-4 text-fire-400" />
                        <span className="text-gray-300">{factor}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Environmental Data */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Thermometer className="w-5 h-5 text-fire-400" />
                      <span className="text-sm text-gray-400">Temperature</span>
                    </div>
                    <div className="text-xl font-bold text-white">
                      {Math.floor(Math.random() * 20) + 25}°C
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Wind className="w-5 h-5 text-cyber-400" />
                      <span className="text-sm text-gray-400">Wind Speed</span>
                    </div>
                    <div className="text-xl font-bold text-white">
                      {Math.floor(Math.random() * 15) + 5} km/h
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Model Performance */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="glass rounded-2xl p-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              Model Performance Metrics
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">94.7%</div>
                <div className="text-gray-400">Accuracy</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-cyber-400 mb-2">91.2%</div>
                <div className="text-gray-400">Precision</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-fire-400 mb-2">89.8%</div>
                <div className="text-gray-400">Recall</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-purple-400 mb-2">2.3s</div>
                <div className="text-gray-400">Avg Response</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Predictions;