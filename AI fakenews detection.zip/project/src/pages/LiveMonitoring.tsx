import React, { useState, useEffect } from 'react';
import { Activity, Wifi, Battery, Signal, Thermometer, Droplets, Wind, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const LiveMonitoring: React.FC = () => {
  const [sensorData, setSensorData] = useState([
    {
      id: 'SENSOR_001',
      name: 'Yellowstone North',
      status: 'online',
      battery: 87,
      signal: 95,
      temperature: 34.2,
      humidity: 23,
      windSpeed: 15.7,
      visibility: 8.2,
      lastUpdate: new Date(),
    },
    {
      id: 'SENSOR_002',
      name: 'Angeles Forest East',
      status: 'online',
      battery: 92,
      signal: 88,
      temperature: 38.5,
      humidity: 18,
      windSpeed: 22.3,
      visibility: 6.1,
      lastUpdate: new Date(),
    },
    {
      id: 'SENSOR_003',
      name: 'Olympic Peninsula',
      status: 'warning',
      battery: 34,
      signal: 76,
      temperature: 28.1,
      humidity: 65,
      windSpeed: 8.9,
      visibility: 12.4,
      lastUpdate: new Date(),
    },
    {
      id: 'SENSOR_004',
      name: 'Smoky Mountains',
      status: 'offline',
      battery: 0,
      signal: 0,
      temperature: 0,
      humidity: 0,
      windSpeed: 0,
      visibility: 0,
      lastUpdate: new Date(Date.now() - 3600000),
    },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSensorData(prev => prev.map(sensor => {
        if (sensor.status === 'online') {
          return {
            ...sensor,
            temperature: sensor.temperature + (Math.random() - 0.5) * 2,
            humidity: Math.max(0, Math.min(100, sensor.humidity + (Math.random() - 0.5) * 5)),
            windSpeed: Math.max(0, sensor.windSpeed + (Math.random() - 0.5) * 3),
            visibility: Math.max(0, Math.min(20, sensor.visibility + (Math.random() - 0.5) * 2)),
            lastUpdate: new Date(),
          };
        }
        return sensor;
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400 bg-green-400/20';
      case 'warning': return 'text-yellow-400 bg-yellow-400/20';
      case 'offline': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getBatteryColor = (battery: number) => {
    if (battery > 60) return 'text-green-400';
    if (battery > 30) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/1670187/pexels-photo-1670187.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Forest monitoring station"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/80" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-cyber bg-clip-text text-transparent">Live Monitoring</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Real-time environmental monitoring through our network of IoT sensors
              deployed across critical forest regions for continuous fire risk assessment.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Network Status */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="glass rounded-2xl p-8 mb-8"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold text-white mb-6 flex items-center">
              <Activity className="w-8 h-8 mr-3 text-cyber-400" />
              Network Status
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">
                  {sensorData.filter(s => s.status === 'online').length}
                </div>
                <div className="text-gray-400">Online Sensors</div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-bold text-yellow-400 mb-2">
                  {sensorData.filter(s => s.status === 'warning').length}
                </div>
                <div className="text-gray-400">Warning Status</div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-bold text-red-400 mb-2">
                  {sensorData.filter(s => s.status === 'offline').length}
                </div>
                <div className="text-gray-400">Offline Sensors</div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-bold text-cyber-400 mb-2">
                  {Math.round((sensorData.filter(s => s.status === 'online').length / sensorData.length) * 100)}%
                </div>
                <div className="text-gray-400">Network Uptime</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Sensor Grid */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {sensorData.map((sensor, index) => (
              <motion.div
                key={sensor.id}
                className="glass rounded-2xl p-8 card-hover"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                {/* Sensor Header */}
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{sensor.name}</h3>
                    <p className="text-gray-400 font-mono text-sm">{sensor.id}</p>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    {/* Status Indicator */}
                    <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(sensor.status)}`}>
                      {sensor.status.toUpperCase()}
                    </div>
                    
                    {/* Signal Strength */}
                    <div className="flex items-center space-x-2">
                      <Signal className="w-5 h-5 text-gray-400" />
                      <span className="text-white font-mono">{sensor.signal}%</span>
                    </div>
                    
                    {/* Battery Level */}
                    <div className="flex items-center space-x-2">
                      <Battery className={`w-5 h-5 ${getBatteryColor(sensor.battery)}`} />
                      <span className={`font-mono ${getBatteryColor(sensor.battery)}`}>
                        {sensor.battery}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Environmental Readings */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Thermometer className="w-5 h-5 text-fire-400" />
                      <span className="text-sm text-gray-400">Temperature</span>
                    </div>
                    <div className="text-2xl font-bold text-white font-mono">
                      {sensor.status === 'offline' ? '--' : `${sensor.temperature.toFixed(1)}°C`}
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Droplets className="w-5 h-5 text-cyber-400" />
                      <span className="text-sm text-gray-400">Humidity</span>
                    </div>
                    <div className="text-2xl font-bold text-white font-mono">
                      {sensor.status === 'offline' ? '--' : `${sensor.humidity.toFixed(0)}%`}
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Wind className="w-5 h-5 text-gray-400" />
                      <span className="text-sm text-gray-400">Wind Speed</span>
                    </div>
                    <div className="text-2xl font-bold text-white font-mono">
                      {sensor.status === 'offline' ? '--' : `${sensor.windSpeed.toFixed(1)} km/h`}
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-lg p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Eye className="w-5 h-5 text-purple-400" />
                      <span className="text-sm text-gray-400">Visibility</span>
                    </div>
                    <div className="text-2xl font-bold text-white font-mono">
                      {sensor.status === 'offline' ? '--' : `${sensor.visibility.toFixed(1)} km`}
                    </div>
                  </div>
                </div>

                {/* Connection Status */}
                <div className="flex items-center justify-between p-4 bg-gray-800/30 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Wifi className={`w-5 h-5 ${sensor.status === 'online' ? 'text-green-400' : 'text-red-400'}`} />
                    <span className="text-sm text-gray-400">Last Update:</span>
                  </div>
                  <span className="text-sm text-white font-mono">
                    {sensor.lastUpdate.toLocaleTimeString()}
                  </span>
                </div>

                {/* Live Data Indicator */}
                {sensor.status === 'online' && (
                  <div className="mt-4 flex items-center justify-center">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                      <span className="text-sm text-green-400">Live Data Stream</span>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Data Analytics */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="glass rounded-2xl p-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-white mb-8 text-center">
              Real-Time Analytics
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-fire-400 mb-2">2.3TB</div>
                <div className="text-gray-400">Data Processed Today</div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-bold text-cyber-400 mb-2">847ms</div>
                <div className="text-gray-400">Average Response Time</div>
              </div>
              
              <div className="text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">99.7%</div>
                <div className="text-gray-400">System Reliability</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default LiveMonitoring;