import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Shield, Database, Wifi, User, Save } from 'lucide-react';
import { motion } from 'framer-motion';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    notifications: {
      emailAlerts: true,
      smsAlerts: false,
      pushNotifications: true,
      alertThreshold: 'medium',
    },
    monitoring: {
      updateInterval: 30,
      dataRetention: 90,
      autoBackup: true,
      sensorCalibration: 'auto',
    },
    security: {
      twoFactorAuth: true,
      sessionTimeout: 60,
      apiAccess: false,
      auditLogging: true,
    },
    display: {
      theme: 'dark',
      language: 'en',
      timezone: 'UTC',
      units: 'metric',
    }
  });

  const handleSettingChange = (category: string, setting: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [setting]: value
      }
    }));
  };

  const handleSave = () => {
    // Save settings logic here
    console.log('Settings saved:', settings);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/1261728/pexels-photo-1261728.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Technology and nature"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/80" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-cyber bg-clip-text text-transparent">Settings</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Configure your ForestGuard AI system preferences, monitoring parameters,
              and security settings for optimal performance and personalized experience.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Settings Panels */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Notifications Settings */}
            <motion.div
              className="glass rounded-2xl p-8"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Bell className="w-6 h-6 mr-3 text-fire-400" />
                Notifications
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">Email Alerts</h3>
                    <p className="text-gray-400 text-sm">Receive fire risk alerts via email</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.notifications.emailAlerts}
                      onChange={(e) => handleSettingChange('notifications', 'emailAlerts', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-fire-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">SMS Alerts</h3>
                    <p className="text-gray-400 text-sm">Critical alerts via SMS</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.notifications.smsAlerts}
                      onChange={(e) => handleSettingChange('notifications', 'smsAlerts', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-fire-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">Push Notifications</h3>
                    <p className="text-gray-400 text-sm">Browser push notifications</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.notifications.pushNotifications}
                      onChange={(e) => handleSettingChange('notifications', 'pushNotifications', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-fire-500"></div>
                  </label>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Alert Threshold</h3>
                  <select
                    value={settings.notifications.alertThreshold}
                    onChange={(e) => handleSettingChange('notifications', 'alertThreshold', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-fire-400 focus:outline-none"
                  >
                    <option value="low">Low Risk and Above</option>
                    <option value="medium">Medium Risk and Above</option>
                    <option value="high">High Risk Only</option>
                    <option value="critical">Critical Risk Only</option>
                  </select>
                </div>
              </div>
            </motion.div>

            {/* Monitoring Settings */}
            <motion.div
              className="glass rounded-2xl p-8"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Wifi className="w-6 h-6 mr-3 text-cyber-400" />
                Monitoring
              </h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-white font-semibold mb-2">Update Interval (seconds)</h3>
                  <input
                    type="range"
                    min="10"
                    max="300"
                    value={settings.monitoring.updateInterval}
                    onChange={(e) => handleSettingChange('monitoring', 'updateInterval', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-sm text-gray-400 mt-1">
                    <span>10s</span>
                    <span className="text-fire-400 font-semibold">{settings.monitoring.updateInterval}s</span>
                    <span>5min</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Data Retention (days)</h3>
                  <input
                    type="range"
                    min="30"
                    max="365"
                    value={settings.monitoring.dataRetention}
                    onChange={(e) => handleSettingChange('monitoring', 'dataRetention', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-sm text-gray-400 mt-1">
                    <span>30 days</span>
                    <span className="text-cyber-400 font-semibold">{settings.monitoring.dataRetention} days</span>
                    <span>1 year</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">Auto Backup</h3>
                    <p className="text-gray-400 text-sm">Automatic data backup</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.monitoring.autoBackup}
                      onChange={(e) => handleSettingChange('monitoring', 'autoBackup', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyber-500"></div>
                  </label>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Sensor Calibration</h3>
                  <select
                    value={settings.monitoring.sensorCalibration}
                    onChange={(e) => handleSettingChange('monitoring', 'sensorCalibration', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-cyber-400 focus:outline-none"
                  >
                    <option value="auto">Automatic</option>
                    <option value="manual">Manual</option>
                    <option value="scheduled">Scheduled</option>
                  </select>
                </div>
              </div>
            </motion.div>

            {/* Security Settings */}
            <motion.div
              className="glass rounded-2xl p-8"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <Shield className="w-6 h-6 mr-3 text-green-400" />
                Security
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">Two-Factor Authentication</h3>
                    <p className="text-gray-400 text-sm">Enhanced account security</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.security.twoFactorAuth}
                      onChange={(e) => handleSettingChange('security', 'twoFactorAuth', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                  </label>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Session Timeout (minutes)</h3>
                  <input
                    type="range"
                    min="15"
                    max="480"
                    value={settings.security.sessionTimeout}
                    onChange={(e) => handleSettingChange('security', 'sessionTimeout', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-sm text-gray-400 mt-1">
                    <span>15min</span>
                    <span className="text-green-400 font-semibold">{settings.security.sessionTimeout}min</span>
                    <span>8hrs</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">API Access</h3>
                    <p className="text-gray-400 text-sm">Allow third-party API access</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.security.apiAccess}
                      onChange={(e) => handleSettingChange('security', 'apiAccess', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-white font-semibold">Audit Logging</h3>
                    <p className="text-gray-400 text-sm">Log all system activities</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.security.auditLogging}
                      onChange={(e) => handleSettingChange('security', 'auditLogging', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                  </label>
                </div>
              </div>
            </motion.div>

            {/* Display Settings */}
            <motion.div
              className="glass rounded-2xl p-8"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <User className="w-6 h-6 mr-3 text-purple-400" />
                Display & Preferences
              </h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-white font-semibold mb-2">Theme</h3>
                  <select
                    value={settings.display.theme}
                    onChange={(e) => handleSettingChange('display', 'theme', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none"
                  >
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                    <option value="auto">Auto</option>
                  </select>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Language</h3>
                  <select
                    value={settings.display.language}
                    onChange={(e) => handleSettingChange('display', 'language', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none"
                  >
                    <option value="en">English</option>
                    <option value="es">Spanish</option>
                    <option value="fr">French</option>
                    <option value="de">German</option>
                  </select>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Timezone</h3>
                  <select
                    value={settings.display.timezone}
                    onChange={(e) => handleSettingChange('display', 'timezone', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none"
                  >
                    <option value="UTC">UTC</option>
                    <option value="EST">Eastern Time</option>
                    <option value="PST">Pacific Time</option>
                    <option value="GMT">Greenwich Mean Time</option>
                  </select>
                </div>

                <div>
                  <h3 className="text-white font-semibold mb-2">Units</h3>
                  <select
                    value={settings.display.units}
                    onChange={(e) => handleSettingChange('display', 'units', e.target.value)}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none"
                  >
                    <option value="metric">Metric</option>
                    <option value="imperial">Imperial</option>
                  </select>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Save Button */}
          <motion.div
            className="mt-8 text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <motion.button
              onClick={handleSave}
              className="px-8 py-4 gradient-fire text-white font-semibold rounded-lg shadow-2xl hover:shadow-fire-500/50 transition-all duration-300 flex items-center space-x-3 mx-auto"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Save className="w-6 h-6" />
              <span>Save All Settings</span>
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Settings;