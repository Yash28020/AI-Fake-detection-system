import React, { useState } from 'react';
import { MapPin, Layers, Filter, Maximize, AlertTriangle, Info } from 'lucide-react';
import { motion } from 'framer-motion';

const RiskMap: React.FC = () => {
  const [selectedLayer, setSelectedLayer] = useState('risk');
  const [selectedRegion, setSelectedRegion] = useState(null);

  const mapLayers = [
    { id: 'risk', name: 'Fire Risk', color: 'text-fire-400' },
    { id: 'temperature', name: 'Temperature', color: 'text-red-400' },
    { id: 'humidity', name: 'Humidity', color: 'text-blue-400' },
    { id: 'wind', name: 'Wind Speed', color: 'text-gray-400' },
    { id: 'vegetation', name: 'Vegetation', color: 'text-green-400' },
  ];

  const riskZones = [
    { id: 1, name: 'Zone Alpha', risk: 'CRITICAL', x: 25, y: 30, size: 'large' },
    { id: 2, name: 'Zone Beta', risk: 'HIGH', x: 60, y: 45, size: 'medium' },
    { id: 3, name: 'Zone Gamma', risk: 'MEDIUM', x: 40, y: 70, size: 'small' },
    { id: 4, name: 'Zone Delta', risk: 'HIGH', x: 75, y: 25, size: 'medium' },
    { id: 5, name: 'Zone Echo', risk: 'LOW', x: 15, y: 80, size: 'small' },
  ];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'CRITICAL': return 'bg-red-500 border-red-400';
      case 'HIGH': return 'bg-fire-500 border-fire-400';
      case 'MEDIUM': return 'bg-yellow-500 border-yellow-400';
      case 'LOW': return 'bg-green-500 border-green-400';
      default: return 'bg-gray-500 border-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/1423600/pexels-photo-1423600.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Aerial forest view"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/70" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-fire bg-clip-text text-transparent">Risk Map</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Interactive geospatial visualization of fire risk zones with real-time environmental data overlay
              and predictive analytics for comprehensive forest monitoring.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Map Interface */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Map Controls */}
            <div className="lg:col-span-1 space-y-6">
              {/* Layer Controls */}
              <motion.div
                className="glass rounded-2xl p-6"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <Layers className="w-6 h-6 mr-3 text-cyber-400" />
                  Map Layers
                </h3>
                
                <div className="space-y-3">
                  {mapLayers.map((layer) => (
                    <motion.button
                      key={layer.id}
                      onClick={() => setSelectedLayer(layer.id)}
                      className={`w-full p-3 rounded-lg text-left transition-all duration-300 ${
                        selectedLayer === layer.id
                          ? 'bg-fire-400/20 border border-fire-400/50'
                          : 'bg-gray-800/50 hover:bg-gray-700/50'
                      }`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded-full ${layer.color.replace('text-', 'bg-')}`} />
                        <span className="text-white font-medium">{layer.name}</span>
                      </div>
                    </motion.button>
                  ))}
                </div>
              </motion.div>

              {/* Risk Legend */}
              <motion.div
                className="glass rounded-2xl p-6"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <AlertTriangle className="w-6 h-6 mr-3 text-fire-400" />
                  Risk Levels
                </h3>
                
                <div className="space-y-3">
                  {['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((level) => (
                    <div key={level} className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full ${getRiskColor(level).split(' ')[0]}`} />
                      <span className="text-gray-300">{level}</span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Map Tools */}
              <motion.div
                className="glass rounded-2xl p-6"
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <Filter className="w-6 h-6 mr-3 text-cyber-400" />
                  Tools
                </h3>
                
                <div className="space-y-3">
                  <button className="w-full p-3 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 text-left text-white transition-all duration-300">
                    <Maximize className="w-4 h-4 inline mr-2" />
                    Fullscreen
                  </button>
                  <button className="w-full p-3 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 text-left text-white transition-all duration-300">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    Add Marker
                  </button>
                </div>
              </motion.div>
            </div>

            {/* Interactive Map */}
            <div className="lg:col-span-3">
              <motion.div
                className="glass rounded-2xl p-8 h-[600px] relative overflow-hidden"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                {/* Map Background */}
                <div className="absolute inset-0 rounded-2xl overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop"
                    alt="Topographic map view"
                    className="w-full h-full object-cover opacity-60"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-black/40 via-transparent to-black/40" />
                </div>

                {/* Risk Zones */}
                <div className="relative z-10 w-full h-full">
                  {riskZones.map((zone, index) => (
                    <motion.div
                      key={zone.id}
                      className={`absolute cursor-pointer ${getRiskColor(zone.risk)} rounded-full border-2 opacity-80 hover:opacity-100 transition-all duration-300`}
                      style={{
                        left: `${zone.x}%`,
                        top: `${zone.y}%`,
                        width: zone.size === 'large' ? '80px' : zone.size === 'medium' ? '60px' : '40px',
                        height: zone.size === 'large' ? '80px' : zone.size === 'medium' ? '60px' : '40px',
                        transform: 'translate(-50%, -50%)'
                      }}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 0.8 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      whileHover={{ scale: 1.2, opacity: 1 }}
                      onClick={() => setSelectedRegion(zone)}
                    >
                      <div className="w-full h-full rounded-full flex items-center justify-center">
                        <AlertTriangle className="w-6 h-6 text-white" />
                      </div>
                      
                      {/* Zone Label */}
                      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-xs text-white font-semibold bg-black/70 px-2 py-1 rounded whitespace-nowrap">
                        {zone.name}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Map Info Panel */}
                <div className="absolute top-4 right-4 glass rounded-lg p-4 max-w-xs">
                  <div className="flex items-center space-x-2 mb-2">
                    <Info className="w-5 h-5 text-cyber-400" />
                    <span className="text-white font-semibold">Map Info</span>
                  </div>
                  <div className="text-sm text-gray-300">
                    <p>Active Layer: <span className="text-fire-400 font-semibold">{selectedLayer}</span></p>
                    <p>Zones Monitored: <span className="text-green-400 font-semibold">{riskZones.length}</span></p>
                    <p>Last Update: <span className="text-cyber-400 font-semibold">2 min ago</span></p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Zone Details */}
      {selectedRegion && (
        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              className="glass rounded-2xl p-8"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-white">
                  {selectedRegion.name} Details
                </h3>
                <button
                  onClick={() => setSelectedRegion(null)}
                  className="text-gray-400 hover:text-white transition-colors duration-300"
                >
                  ✕
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Risk Level</div>
                  <div className={`text-2xl font-bold ${
                    selectedRegion.risk === 'CRITICAL' ? 'text-red-400' :
                    selectedRegion.risk === 'HIGH' ? 'text-fire-400' :
                    selectedRegion.risk === 'MEDIUM' ? 'text-yellow-400' : 'text-green-400'
                  }`}>
                    {selectedRegion.risk}
                  </div>
                </div>
                
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Probability</div>
                  <div className="text-2xl font-bold text-fire-400">
                    {selectedRegion.risk === 'CRITICAL' ? '94%' :
                     selectedRegion.risk === 'HIGH' ? '78%' :
                     selectedRegion.risk === 'MEDIUM' ? '45%' : '23%'}
                  </div>
                </div>
                
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Last Updated</div>
                  <div className="text-2xl font-bold text-cyber-400">2 min</div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      )}
    </div>
  );
};

export default RiskMap;