import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Zap, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const LiveDemo: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const demoSteps = [
    {
      title: 'Satellite Data Acquisition',
      description: 'Fetching real-time satellite imagery from NASA MODIS and Sentinel-2',
      duration: 3000,
      status: 'processing'
    },
    {
      title: 'Environmental Analysis',
      description: 'Processing temperature, humidity, and wind data',
      duration: 2500,
      status: 'processing'
    },
    {
      title: 'AI Model Inference',
      description: 'Running CNN and LSTM models for fire risk prediction',
      duration: 4000,
      status: 'processing'
    },
    {
      title: 'Risk Assessment',
      description: 'Calculating fire probability and generating alerts',
      duration: 2000,
      status: 'processing'
    },
    {
      title: 'Alert Generation',
      description: 'Preparing notifications for high-risk areas',
      duration: 1500,
      status: 'completed'
    }
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setCurrentStep(prevStep => {
              if (prevStep >= demoSteps.length - 1) {
                setIsRunning(false);
                return prevStep;
              }
              return prevStep + 1;
            });
            return 0;
          }
          return prev + 2;
        });
      }, 50);
    }

    return () => clearInterval(interval);
  }, [isRunning, currentStep]);

  const handleStart = () => {
    setIsRunning(true);
    setCurrentStep(0);
    setProgress(0);
  };

  const handleReset = () => {
    setIsRunning(false);
    setCurrentStep(0);
    setProgress(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Hero Section with Forest Background */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/1671325/pexels-photo-1671325.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Forest landscape"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/70" />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="gradient-fire bg-clip-text text-transparent">Live Demo</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Experience our AI-powered forest fire prediction system in real-time.
              Watch as our advanced algorithms process environmental data and generate accurate fire risk assessments.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Demo Controls */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="glass rounded-2xl p-8 mb-12"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex flex-col md:flex-row items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-white mb-4 md:mb-0">
                AI Processing Pipeline Demo
              </h2>
              
              <div className="flex items-center space-x-4">
                <motion.button
                  onClick={handleStart}
                  disabled={isRunning}
                  className={`px-6 py-3 rounded-lg font-semibold flex items-center space-x-2 transition-all duration-300 ${
                    isRunning 
                      ? 'bg-gray-600 text-gray-400 cursor-not-allowed' 
                      : 'gradient-fire text-white hover:shadow-lg hover:shadow-fire-500/30'
                  }`}
                  whileHover={!isRunning ? { scale: 1.05 } : {}}
                  whileTap={!isRunning ? { scale: 0.95 } : {}}
                >
                  {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  <span>{isRunning ? 'Running...' : 'Start Demo'}</span>
                </motion.button>
                
                <motion.button
                  onClick={handleReset}
                  className="px-6 py-3 rounded-lg font-semibold flex items-center space-x-2 glass border border-white/20 hover:border-white/40 transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <RotateCcw className="w-5 h-5" />
                  <span>Reset</span>
                </motion.button>
              </div>
            </div>

            {/* Processing Steps */}
            <div className="space-y-6">
              {demoSteps.map((step, index) => (
                <motion.div
                  key={step.title}
                  className={`p-6 rounded-xl border transition-all duration-500 ${
                    index === currentStep && isRunning
                      ? 'border-fire-400 bg-fire-400/10'
                      : index < currentStep
                        ? 'border-green-400 bg-green-400/10'
                        : 'border-gray-600 bg-gray-800/30'
                  }`}
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        index === currentStep && isRunning
                          ? 'bg-fire-400 text-white animate-pulse'
                          : index < currentStep
                            ? 'bg-green-400 text-white'
                            : 'bg-gray-600 text-gray-400'
                      }`}>
                        {index < currentStep ? (
                          <CheckCircle className="w-6 h-6" />
                        ) : index === currentStep && isRunning ? (
                          <Zap className="w-6 h-6" />
                        ) : (
                          <span className="font-bold">{index + 1}</span>
                        )}
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                        <p className="text-gray-400">{step.description}</p>
                      </div>
                    </div>
                    
                    {index === currentStep && isRunning && (
                      <div className="text-right">
                        <div className="text-2xl font-bold text-fire-400 font-mono">
                          {progress.toFixed(0)}%
                        </div>
                        <div className="text-sm text-gray-400">Processing</div>
                      </div>
                    )}
                  </div>
                  
                  {/* Progress Bar */}
                  {index === currentStep && isRunning && (
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <motion.div
                        className="h-2 rounded-full bg-gradient-to-r from-fire-500 to-fire-400"
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.1 }}
                      />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Demo Results */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="glass rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <AlertTriangle className="w-8 h-8 text-fire-400" />
                <h3 className="text-xl font-bold text-white">Risk Level</h3>
              </div>
              <div className="text-4xl font-bold text-fire-400 mb-2">HIGH</div>
              <p className="text-gray-400">Current fire risk assessment for monitored regions</p>
            </div>

            <div className="glass rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <CheckCircle className="w-8 h-8 text-green-400" />
                <h3 className="text-xl font-bold text-white">Accuracy</h3>
              </div>
              <div className="text-4xl font-bold text-green-400 mb-2">94.7%</div>
              <p className="text-gray-400">Model prediction accuracy rate</p>
            </div>

            <div className="glass rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Zap className="w-8 h-8 text-cyber-400" />
                <h3 className="text-xl font-bold text-white">Processing Time</h3>
              </div>
              <div className="text-4xl font-bold text-cyber-400 mb-2">2.3s</div>
              <p className="text-gray-400">Average prediction processing time</p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default LiveDemo;